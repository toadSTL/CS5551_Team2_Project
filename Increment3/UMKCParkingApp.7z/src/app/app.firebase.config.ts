export const firebaseConfig = {
	fire: {
		apiKey: "AIzaSyA1yy7B1myPUILTE2ztUm7Zu1d3U74Xq8E",
        authDomain: "umkc-parking-app.firebaseapp.com",
        databaseURL: "https://umkc-parking-app.firebaseio.com",
        projectId: "umkc-parking-app",
        storageBucket: "umkc-parking-app.appspot.com",
        messagingSenderId: "309431257659"
	}
};